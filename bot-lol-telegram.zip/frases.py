frases_lol = [
    "A justiça irá triunfar - Garen",
    "É hora de caçar - Rengar",
    "Demacia! - Garen",
    "Você não pode conter a maré - Nami",
    "O equilíbrio é a chave - Shen",
    "O tempo voa como uma flecha; frutas voam como bananas - Jhin"
]
