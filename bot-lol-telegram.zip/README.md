# 🤖 Bot do League of Legends no Telegram

Este projeto é um bot interativo do **League of Legends (LoL)** para Telegram, criado com Python. Ele permite que os usuários:

- Recebam **frases icônicas de campeões**
- Participem de **quizzes interativos** com múltipla escolha (clique em botões)
- Visualizem **explicações** após cada resposta
- Tenham suas pontuações (acertos e erros) armazenadas

---

## 🚀 Tecnologias Utilizadas

- Python 3.12
- [python-telegram-bot v20+](https://github.com/python-telegram-bot/python-telegram-bot)
- Estrutura modular em arquivos (`bot.py`, `quiz.py`, `frases.py`, `pontuacao.py`, `config.py`)

---

## 📦 Instalação

1. Clone este repositório:

```bash
git clone https://github.com/seuusuario/bot-lol-telegram.git
cd bot-lol-telegram
```

2. Instale as dependências:

```bash
pip install python-telegram-bot
```

3. Adicione seu token do bot no arquivo `config.py`:

```python
BOT_TOKEN = "SEU_TOKEN_AQUI"
```

4. Execute o bot:

```bash
python bot.py
```

---

## 🧠 Créditos e Temas

- As perguntas do quiz incluem temas do **competitivo brasileiro e internacional**, campeões e curiosidades do LoL.
- Inspirado em fãs da FURIA e da comunidade de e-sports.

---

## 📜 Licença

Este projeto está licenciado sob a licença MIT.

---

Desenvolvido por Rômulo Augusto Vieira com apoio do ChatGPT 🤖
