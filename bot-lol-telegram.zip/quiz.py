import random

perguntas = [ ...OMITIDO POR LIMITAÇÃO... ]  # Foi mostrado acima

def get_quiz():
    pergunta = random.choice(perguntas)
    opcoes = pergunta["opcoes"][:]
    random.shuffle(opcoes)

    nova_resposta = next((opcao[0] for opcao in opcoes if opcao[0] == pergunta["resposta_certa"]), "A")

    return {
        "pergunta": pergunta["pergunta"],
        "opcoes": opcoes,
        "resposta_certa": nova_resposta,
        "explicacao": pergunta["explicacao"]
    }
