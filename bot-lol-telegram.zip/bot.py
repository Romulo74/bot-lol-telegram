import logging
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, CallbackQueryHandler, ContextTypes
from frases import frases_lol
from quiz import get_quiz
from pontuacao import pontuacoes
import random
import config

logging.basicConfig(level=logging.INFO)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Seja bem-vindo ao Bot do LoL! Use /frase para uma frase aleatória ou /quiz para começar um quiz!")

async def frase(update: Update, context: ContextTypes.DEFAULT_TYPE):
    frase = random.choice(frases_lol)
    await update.message.reply_text(frase)

async def quiz(update: Update, context: ContextTypes.DEFAULT_TYPE):
    quiz = get_quiz()
    keyboard = [
        [InlineKeyboardButton(opcao, callback_data=opcao[0])] for opcao in quiz["opcoes"]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)

    context.user_data["resposta_certa"] = quiz["resposta_certa"]
    context.user_data["explicacao"] = quiz["explicacao"]

    await update.message.reply_text(quiz["pergunta"], reply_markup=reply_markup)

async def button(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    resposta_usuario = query.data
    resposta_certa = context.user_data.get("resposta_certa")
    explicacao = context.user_data.get("explicacao", "")

    user_id = query.from_user.id
    if resposta_usuario == resposta_certa:
        pontuacoes[user_id] = pontuacoes.get(user_id, {"acertos": 0, "erros": 0})
        pontuacoes[user_id]["acertos"] += 1
        resposta = "✅ Resposta correta!

"
    else:
        pontuacoes[user_id] = pontuacoes.get(user_id, {"acertos": 0, "erros": 0})
        pontuacoes[user_id]["erros"] += 1
        resposta = f"❌ Resposta errada. A resposta correta era '{resposta_certa}'.

"

    resposta += f"🧠 Explicação: {explicacao}"
    await query.edit_message_text(resposta)

def main():
    app = ApplicationBuilder().token(config.BOT_TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("frase", frase))
    app.add_handler(CommandHandler("quiz", quiz))
    app.add_handler(CallbackQueryHandler(button))

    app.run_polling()

if __name__ == "__main__":
    main()
